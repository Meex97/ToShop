package unito.project.toshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToshopApplication.class, args);
	}

}
